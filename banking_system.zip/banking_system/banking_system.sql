-- ================================================
--  BANKING SYSTEM - MySQL Version (For XAMPP)
--  Run this in phpMyAdmin or MySQL command line
-- ================================================

CREATE DATABASE IF NOT EXISTS BankingSystem;
USE BankingSystem;

-- ================================================
--  TABLES
-- ================================================

CREATE TABLE IF NOT EXISTS Customers (
    customer_id  INT          AUTO_INCREMENT PRIMARY KEY,
    name         VARCHAR(100) NOT NULL,
    phone        VARCHAR(20)  UNIQUE NOT NULL,
    city         VARCHAR(50)  NOT NULL,
    created_at   DATETIME     DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS Branches (
    branch_id    INT          AUTO_INCREMENT PRIMARY KEY,
    branch_name  VARCHAR(100) NOT NULL,
    location     VARCHAR(100) NOT NULL
);

CREATE TABLE IF NOT EXISTS Accounts (
    account_id   INT            AUTO_INCREMENT PRIMARY KEY,
    customer_id  INT            NOT NULL,
    branch_id    INT            NOT NULL,
    account_type VARCHAR(20)    NOT NULL DEFAULT 'SAVINGS',
    balance      DECIMAL(12,2)  DEFAULT 0,
    CONSTRAINT CHK_AccountType CHECK (account_type IN ('SAVINGS', 'CURRENT')),
    CONSTRAINT CHK_Balance CHECK (balance >= 0),
    FOREIGN KEY (customer_id) REFERENCES Customers(customer_id) ON DELETE CASCADE,
    FOREIGN KEY (branch_id)   REFERENCES Branches(branch_id)   ON DELETE CASCADE
) AUTO_INCREMENT=1000;

CREATE TABLE IF NOT EXISTS Transactions (
    txn_id       INT            AUTO_INCREMENT PRIMARY KEY,
    sender_acc   INT            NULL,
    receiver_acc INT            NULL,
    amount       DECIMAL(12,2)  NOT NULL,
    txn_type     VARCHAR(20)    NOT NULL,
    txn_date     DATETIME       DEFAULT NOW(),
    CONSTRAINT CHK_Amount CHECK (amount > 0),
    CONSTRAINT CHK_TxnType CHECK (txn_type IN ('DEPOSIT', 'WITHDRAW', 'TRANSFER')),
    CONSTRAINT CHK_ValidTransaction CHECK (sender_acc IS NOT NULL OR receiver_acc IS NOT NULL)
);

-- ================================================
--  INDEXES
-- ================================================

CREATE INDEX IX_Accounts_Customer     ON Accounts(customer_id);
CREATE INDEX IX_Accounts_Branch       ON Accounts(branch_id);
CREATE INDEX IX_Transactions_Sender   ON Transactions(sender_acc);
CREATE INDEX IX_Transactions_Receiver ON Transactions(receiver_acc);

-- ================================================
--  SAMPLE DATA
-- ================================================

INSERT INTO Customers (name, phone, city) VALUES
('Ali Khan',      '03001234567', 'Lahore'),
('Sara Ahmed',    '03111234567', 'Karachi'),
('Usman Tariq',   '03331234567', 'Islamabad'),
('Ayesha Malik',  '03221234567', 'Lahore'),
('Bilal Chaudhry','03451234567', 'Karachi');

INSERT INTO Branches (branch_name, location) VALUES
('Main Branch',      'Lahore'),
('City Branch',      'Karachi'),
('Blue Area Branch', 'Islamabad');

INSERT INTO Accounts (customer_id, branch_id, account_type, balance) VALUES
(1, 1, 'SAVINGS',  15000),
(2, 2, 'CURRENT',   9000),
(3, 3, 'SAVINGS',   4000),
(4, 1, 'SAVINGS',  20000),
(5, 2, 'CURRENT',   2500);

-- ================================================
--  STORED PROCEDURES
-- ================================================

DELIMITER $$

CREATE PROCEDURE TransferMoney(
    IN p_sender   INT,
    IN p_receiver INT,
    IN p_amount   DECIMAL(12,2)
)
BEGIN
    DECLARE sender_balance DECIMAL(12,2);
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        ROLLBACK;
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Transfer failed due to database error.';
    END;

    IF p_sender = p_receiver THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Sender and receiver cannot be the same account.';
    END IF;

    IF p_amount <= 0 THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Transfer amount must be greater than zero.';
    END IF;

    START TRANSACTION;

    SELECT balance INTO sender_balance FROM Accounts WHERE account_id = p_sender FOR UPDATE;

    IF sender_balance < p_amount THEN
        ROLLBACK;
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Insufficient balance for this transfer.';
    END IF;

    UPDATE Accounts SET balance = balance - p_amount WHERE account_id = p_sender;
    UPDATE Accounts SET balance = balance + p_amount WHERE account_id = p_receiver;

    INSERT INTO Transactions (sender_acc, receiver_acc, amount, txn_type)
    VALUES (p_sender, p_receiver, p_amount, 'TRANSFER');

    COMMIT;
END$$

CREATE PROCEDURE DepositWithdraw(
    IN p_acc_id INT,
    IN p_amount DECIMAL(12,2),
    IN p_type   VARCHAR(10)
)
BEGIN
    DECLARE current_balance DECIMAL(12,2);
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        ROLLBACK;
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Transaction failed due to database error.';
    END;

    IF p_type NOT IN ('DEPOSIT', 'WITHDRAW') THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Invalid type. Use DEPOSIT or WITHDRAW only.';
    END IF;

    IF p_amount <= 0 THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Amount must be greater than zero.';
    END IF;

    START TRANSACTION;

    IF p_type = 'DEPOSIT' THEN
        UPDATE Accounts SET balance = balance + p_amount WHERE account_id = p_acc_id;
        INSERT INTO Transactions (sender_acc, receiver_acc, amount, txn_type)
        VALUES (NULL, p_acc_id, p_amount, 'DEPOSIT');
    ELSE
        SELECT balance INTO current_balance FROM Accounts WHERE account_id = p_acc_id FOR UPDATE;
        IF current_balance < p_amount THEN
            ROLLBACK;
            SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Insufficient balance for withdrawal.';
        END IF;
        UPDATE Accounts SET balance = balance - p_amount WHERE account_id = p_acc_id;
        INSERT INTO Transactions (sender_acc, receiver_acc, amount, txn_type)
        VALUES (p_acc_id, NULL, p_amount, 'WITHDRAW');
    END IF;

    COMMIT;
END$$

DELIMITER ;
