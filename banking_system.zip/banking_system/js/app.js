const API = 'api/';

// ---- Navigation ----
function showTab(tab) {
    document.querySelectorAll('.tab-content').forEach(t => t.classList.remove('active'));
    document.querySelectorAll('.nav-item').forEach(n => n.classList.remove('active'));
    document.getElementById('tab-' + tab).classList.add('active');
    document.querySelector(`[data-tab="${tab}"]`).classList.add('active');
    loaders[tab] && loaders[tab]();
}

// ---- Helpers ----
function fmt(n) { return 'Rs. ' + parseFloat(n).toLocaleString('en-PK', {minimumFractionDigits:2}); }
function fmtDate(d) { return d ? new Date(d).toLocaleString('en-PK') : '-'; }

function showAlert(id, msg, type) {
    const el = document.getElementById(id);
    el.textContent = msg;
    el.className = `alert alert-${type} show`;
    setTimeout(() => el.classList.remove('show'), 4000);
}

async function api(endpoint, method='GET', body=null) {
    const opts = { method, headers: {'Content-Type':'application/json'} };
    if (body) opts.body = JSON.stringify(body);
    const res = await fetch(API + endpoint, opts);
    return res.json();
}

// ---- DASHBOARD ----
async function loadDashboard() {
    const d = await api('dashboard.php');
    if (!d.success) return;

    document.getElementById('stat-balance').textContent   = fmt(d.total_balance);
    document.getElementById('stat-customers').textContent = d.total_customers;
    document.getElementById('stat-accounts').textContent  = d.total_accounts;
    document.getElementById('stat-txns').textContent      = d.total_txns;

    // Branch stats
    const bc = document.getElementById('branch-cards');
    bc.innerHTML = d.branch_stats.map(b => `
        <div class="branch-card">
            <h4>${b.branch_name}</h4>
            <div class="bl"><span>Accounts:</span><strong>${b.total_accounts}</strong></div>
            <div class="bl"><span>Total Balance:</span><strong>${fmt(b.total_balance)}</strong></div>
            <div class="bl"><span>Avg Balance:</span><strong>${fmt(b.avg_balance)}</strong></div>
        </div>
    `).join('');

    // Recent transactions
    const rt = document.getElementById('recent-txns');
    if (d.recent_txns.length === 0) {
        rt.innerHTML = '<tr><td colspan="5" style="text-align:center;color:#9ca3af;padding:20px">No transactions yet</td></tr>';
        return;
    }
    rt.innerHTML = d.recent_txns.map(t => `
        <tr>
            <td>#${t.txn_id}</td>
            <td><span class="badge badge-${t.txn_type.toLowerCase()}">${t.txn_type}</span></td>
            <td>${fmt(t.amount)}</td>
            <td>${t.sender_name || '-'} ${t.receiver_name ? '→ ' + t.receiver_name : ''}</td>
            <td>${fmtDate(t.txn_date)}</td>
        </tr>
    `).join('');

    // Low balance alerts
    const lb = document.getElementById('low-balance-rows');
    if (d.low_balance.length === 0) {
        lb.innerHTML = '<tr><td colspan="4" style="text-align:center;color:#9ca3af;padding:20px">No low balance accounts</td></tr>';
    } else {
        lb.innerHTML = d.low_balance.map(a => `
            <tr class="low-alert-row">
                <td>${a.account_id}</td>
                <td>${a.customer_name}</td>
                <td>${fmt(a.balance)}</td>
                <td><span class="badge badge-low">LOW BALANCE</span></td>
            </tr>
        `).join('');
    }
}

// ---- CUSTOMERS ----
async function loadCustomers() {
    const d = await api('customers.php?action=list');
    const tb = document.getElementById('customers-tbody');
    if (!d.success || d.data.length === 0) {
        tb.innerHTML = '<tr><td colspan="5" style="text-align:center;color:#9ca3af;padding:20px">No customers found</td></tr>';
        return;
    }
    tb.innerHTML = d.data.map(c => `
        <tr>
            <td>${c.customer_id}</td>
            <td><strong>${c.name}</strong></td>
            <td>${c.phone}</td>
            <td>${c.city}</td>
            <td>${fmtDate(c.created_at)}</td>
        </tr>
    `).join('');
    loadCustomerDropdowns();
}

async function addCustomer() {
    const name  = document.getElementById('c-name').value.trim();
    const phone = document.getElementById('c-phone').value.trim();
    const city  = document.getElementById('c-city').value.trim();
    if (!name || !phone || !city) return showAlert('cust-alert', 'All fields are required.', 'danger');

    const d = await api('customers.php?action=add', 'POST', {name, phone, city});
    showAlert('cust-alert', d.message, d.success ? 'success' : 'danger');
    if (d.success) {
        document.getElementById('c-name').value = '';
        document.getElementById('c-phone').value = '';
        document.getElementById('c-city').value = '';
        loadCustomers();
    }
}

// ---- BRANCHES ----
async function loadBranches() {
    const d = await api('branches.php?action=list');
    const tb = document.getElementById('branches-tbody');
    if (!d.success || d.data.length === 0) {
        tb.innerHTML = '<tr><td colspan="3" style="text-align:center;color:#9ca3af;padding:20px">No branches found</td></tr>';
        return;
    }
    tb.innerHTML = d.data.map(b => `
        <tr>
            <td>${b.branch_id}</td>
            <td><strong>${b.branch_name}</strong></td>
            <td>${b.location}</td>
        </tr>
    `).join('');
    loadBranchDropdowns();
}

async function addBranch() {
    const branch_name = document.getElementById('b-name').value.trim();
    const location    = document.getElementById('b-location').value.trim();
    if (!branch_name || !location) return showAlert('branch-alert', 'All fields are required.', 'danger');

    const d = await api('branches.php?action=add', 'POST', {branch_name, location});
    showAlert('branch-alert', d.message, d.success ? 'success' : 'danger');
    if (d.success) {
        document.getElementById('b-name').value = '';
        document.getElementById('b-location').value = '';
        loadBranches();
    }
}

// ---- ACCOUNTS ----
async function loadAccounts() {
    const d = await api('accounts.php?action=list');
    const tb = document.getElementById('accounts-tbody');
    if (!d.success || d.data.length === 0) {
        tb.innerHTML = '<tr><td colspan="7" style="text-align:center;color:#9ca3af;padding:20px">No accounts found</td></tr>';
        return;
    }
    tb.innerHTML = d.data.map(a => `
        <tr>
            <td><strong>${a.account_id}</strong></td>
            <td>${a.customer_name}<br><small style="color:#9ca3af">${a.phone}</small></td>
            <td>${a.branch_name}</td>
            <td><span class="badge badge-${a.account_type.toLowerCase()}">${a.account_type}</span></td>
            <td><strong>${fmt(a.balance)}</strong></td>
            <td><span class="badge badge-${a.account_status.toLowerCase()}">${a.account_status}</span></td>
            <td>${a.city}</td>
        </tr>
    `).join('');
}

async function addAccount() {
    const customer_id  = document.getElementById('a-customer').value;
    const branch_id    = document.getElementById('a-branch').value;
    const account_type = document.getElementById('a-type').value;
    const balance      = document.getElementById('a-balance').value;

    if (!customer_id || !branch_id) return showAlert('acc-alert', 'Select customer and branch.', 'danger');

    const d = await api('accounts.php?action=add', 'POST', {customer_id, branch_id, account_type, balance});
    showAlert('acc-alert', d.message || (d.success ? 'Account created. ID: ' + d.account_id : 'Error'), d.success ? 'success' : 'danger');
    if (d.success) { document.getElementById('a-balance').value = ''; loadAccounts(); loadAccountDropdowns(); }
}

// ---- TRANSACTIONS ----
async function loadTransactions() {
    const d = await api('transactions.php');
    const tb = document.getElementById('txns-tbody');
    if (!d.success || d.data.length === 0) {
        tb.innerHTML = '<tr><td colspan="6" style="text-align:center;color:#9ca3af;padding:20px">No transactions found</td></tr>';
        return;
    }
    tb.innerHTML = d.data.map(t => `
        <tr>
            <td>#${t.txn_id}</td>
            <td><span class="badge badge-${t.txn_type.toLowerCase()}">${t.txn_type}</span></td>
            <td><strong>${fmt(t.amount)}</strong></td>
            <td>${t.sender_acc ? `Acc #${t.sender_acc}${t.sender_name ? ' (' + t.sender_name + ')' : ''}` : '-'}</td>
            <td>${t.receiver_acc ? `Acc #${t.receiver_acc}${t.receiver_name ? ' (' + t.receiver_name + ')' : ''}` : '-'}</td>
            <td>${fmtDate(t.txn_date)}</td>
        </tr>
    `).join('');
}

// ---- DEPOSIT / WITHDRAW ----
async function doDepositWithdraw(type) {
    const account_id = document.getElementById('dw-account').value;
    const amount     = document.getElementById('dw-amount').value;
    if (!account_id || !amount) return showAlert('dw-alert', 'Please fill all fields.', 'danger');

    const d = await api('deposit_withdraw.php', 'POST', {account_id: parseInt(account_id), amount: parseFloat(amount), type});
    showAlert('dw-alert', d.message, d.success ? 'success' : 'danger');
    if (d.success) { document.getElementById('dw-amount').value = ''; loadDashboard(); }
}

// ---- TRANSFER ----
async function doTransfer() {
    const sender_acc   = document.getElementById('tr-sender').value;
    const receiver_acc = document.getElementById('tr-receiver').value;
    const amount       = document.getElementById('tr-amount').value;
    if (!sender_acc || !receiver_acc || !amount) return showAlert('tr-alert', 'Please fill all fields.', 'danger');

    const d = await api('transfer.php', 'POST', {sender_acc: parseInt(sender_acc), receiver_acc: parseInt(receiver_acc), amount: parseFloat(amount)});
    showAlert('tr-alert', d.message, d.success ? 'success' : 'danger');
    if (d.success) { document.getElementById('tr-amount').value = ''; loadDashboard(); }
}

// ---- DROPDOWNS ----
async function loadCustomerDropdowns() {
    const d = await api('customers.php?action=list');
    if (!d.success) return;
    const opts = d.data.map(c => `<option value="${c.customer_id}">${c.name} (${c.phone})</option>`).join('');
    document.getElementById('a-customer').innerHTML = '<option value="">Select Customer</option>' + opts;
}

async function loadBranchDropdowns() {
    const d = await api('branches.php?action=list');
    if (!d.success) return;
    const opts = d.data.map(b => `<option value="${b.branch_id}">${b.branch_name} - ${b.location}</option>`).join('');
    document.getElementById('a-branch').innerHTML = '<option value="">Select Branch</option>' + opts;
}

async function loadAccountDropdowns() {
    const d = await api('accounts.php?action=list');
    if (!d.success) return;
    const opts = d.data.map(a => `<option value="${a.account_id}">Acc #${a.account_id} - ${a.customer_name} (${fmt(a.balance)})</option>`).join('');
    const sel = '<option value="">Select Account</option>' + opts;
    ['dw-account','tr-sender','tr-receiver'].forEach(id => {
        document.getElementById(id).innerHTML = sel;
    });
}

// ---- LOADER MAP ----
const loaders = {
    dashboard:   loadDashboard,
    customers:   () => { loadCustomers(); },
    branches:    () => { loadBranches(); },
    accounts:    () => { loadAccounts(); loadCustomerDropdowns(); loadBranchDropdowns(); },
    transactions: loadTransactions,
    depwith:     loadAccountDropdowns,
    transfer:    loadAccountDropdowns
};

// ---- INIT ----
document.addEventListener('DOMContentLoaded', () => {
    showTab('dashboard');
});
