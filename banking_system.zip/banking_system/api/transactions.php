<?php
require_once '../config.php';

$db = getDB();

$sql = "
    SELECT
        t.txn_id,
        t.txn_type,
        t.amount,
        t.txn_date,
        t.sender_acc,
        t.receiver_acc,
        sc.name  AS sender_name,
        rc.name  AS receiver_name
    FROM Transactions t
    LEFT JOIN Accounts  sa ON t.sender_acc   = sa.account_id
    LEFT JOIN Customers sc ON sa.customer_id = sc.customer_id
    LEFT JOIN Accounts  ra ON t.receiver_acc = ra.account_id
    LEFT JOIN Customers rc ON ra.customer_id = rc.customer_id
    ORDER BY t.txn_date DESC
    LIMIT 100
";

$result = $db->query($sql);
$rows = [];
while ($row = $result->fetch_assoc()) $rows[] = $row;
echo json_encode(['success' => true, 'data' => $rows]);

$db->close();
