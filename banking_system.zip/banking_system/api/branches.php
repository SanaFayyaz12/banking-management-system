<?php
require_once '../config.php';

$db = getDB();
$method = $_SERVER['REQUEST_METHOD'];
$action = $_GET['action'] ?? 'list';

if ($method === 'GET' && $action === 'list') {
    $result = $db->query("SELECT * FROM Branches ORDER BY branch_id");
    $rows = [];
    while ($row = $result->fetch_assoc()) $rows[] = $row;
    echo json_encode(['success' => true, 'data' => $rows]);

} elseif ($method === 'POST' && $action === 'add') {
    $input = json_decode(file_get_contents('php://input'), true);
    $name  = trim($input['branch_name'] ?? '');
    $loc   = trim($input['location'] ?? '');

    if (!$name || !$loc) {
        echo json_encode(['success' => false, 'message' => 'All fields are required.']);
        exit;
    }

    $stmt = $db->prepare("INSERT INTO Branches (branch_name, location) VALUES (?, ?)");
    $stmt->bind_param('ss', $name, $loc);
    $stmt->execute();
    echo json_encode(['success' => true, 'message' => 'Branch added.', 'id' => $db->insert_id]);
} else {
    echo json_encode(['success' => false, 'message' => 'Invalid request.']);
}

$db->close();
