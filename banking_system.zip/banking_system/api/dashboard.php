<?php
require_once '../config.php';

$db = getDB();

$total_balance = $db->query("SELECT IFNULL(SUM(balance),0) AS total FROM Accounts")->fetch_assoc()['total'];
$total_customers = $db->query("SELECT COUNT(*) AS c FROM Customers")->fetch_assoc()['c'];
$total_accounts  = $db->query("SELECT COUNT(*) AS c FROM Accounts")->fetch_assoc()['c'];
$total_txns      = $db->query("SELECT COUNT(*) AS c FROM Transactions")->fetch_assoc()['c'];

$branch_stats_result = $db->query("
    SELECT b.branch_name, COUNT(a.account_id) AS total_accounts,
           IFNULL(SUM(a.balance),0) AS total_balance,
           IFNULL(AVG(a.balance),0) AS avg_balance
    FROM Branches b
    LEFT JOIN Accounts a ON b.branch_id = a.branch_id
    GROUP BY b.branch_id, b.branch_name
");
$branch_stats = [];
while ($row = $branch_stats_result->fetch_assoc()) $branch_stats[] = $row;

$low_balance_result = $db->query("
    SELECT a.account_id, c.name AS customer_name, a.balance, a.account_type,
           CASE WHEN a.balance < 5000 THEN 'LOW' WHEN a.balance < 10000 THEN 'MODERATE' ELSE 'GOOD' END AS status
    FROM Accounts a
    JOIN Customers c ON a.customer_id = c.customer_id
    WHERE a.balance < 5000
    ORDER BY a.balance ASC
");
$low_balance = [];
while ($row = $low_balance_result->fetch_assoc()) $low_balance[] = $row;

$recent_txns_result = $db->query("
    SELECT t.txn_id, t.txn_type, t.amount, t.txn_date,
           sc.name AS sender_name, rc.name AS receiver_name
    FROM Transactions t
    LEFT JOIN Accounts sa  ON t.sender_acc   = sa.account_id
    LEFT JOIN Customers sc ON sa.customer_id = sc.customer_id
    LEFT JOIN Accounts ra  ON t.receiver_acc = ra.account_id
    LEFT JOIN Customers rc ON ra.customer_id = rc.customer_id
    ORDER BY t.txn_date DESC LIMIT 5
");
$recent_txns = [];
while ($row = $recent_txns_result->fetch_assoc()) $recent_txns[] = $row;

echo json_encode([
    'success'         => true,
    'total_balance'   => $total_balance,
    'total_customers' => $total_customers,
    'total_accounts'  => $total_accounts,
    'total_txns'      => $total_txns,
    'branch_stats'    => $branch_stats,
    'low_balance'     => $low_balance,
    'recent_txns'     => $recent_txns
]);

$db->close();
