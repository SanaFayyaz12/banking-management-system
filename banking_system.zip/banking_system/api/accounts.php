<?php
require_once '../config.php';

$db = getDB();
$method = $_SERVER['REQUEST_METHOD'];
$action = $_GET['action'] ?? 'list';

if ($method === 'GET' && $action === 'list') {
    $sql = "
        SELECT a.account_id, a.account_type, a.balance,
               c.name AS customer_name, c.phone, c.city,
               b.branch_name, b.location,
               CASE
                   WHEN a.balance < 5000  THEN 'LOW'
                   WHEN a.balance < 10000 THEN 'MODERATE'
                   ELSE 'GOOD'
               END AS account_status
        FROM Accounts a
        JOIN Customers c ON a.customer_id = c.customer_id
        JOIN Branches  b ON a.branch_id   = b.branch_id
        ORDER BY a.account_id
    ";
    $result = $db->query($sql);
    $rows = [];
    while ($row = $result->fetch_assoc()) $rows[] = $row;
    echo json_encode(['success' => true, 'data' => $rows]);

} elseif ($method === 'POST' && $action === 'add') {
    $input       = json_decode(file_get_contents('php://input'), true);
    $cust_id     = intval($input['customer_id'] ?? 0);
    $branch_id   = intval($input['branch_id'] ?? 0);
    $acc_type    = $input['account_type'] ?? 'SAVINGS';
    $balance     = floatval($input['balance'] ?? 0);

    if (!$cust_id || !$branch_id || !in_array($acc_type, ['SAVINGS','CURRENT']) || $balance < 0) {
        echo json_encode(['success' => false, 'message' => 'Invalid input.']);
        exit;
    }

    $stmt = $db->prepare("INSERT INTO Accounts (customer_id, branch_id, account_type, balance) VALUES (?, ?, ?, ?)");
    $stmt->bind_param('iisd', $cust_id, $branch_id, $acc_type, $balance);
    $stmt->execute();
    echo json_encode(['success' => true, 'message' => 'Account created.', 'account_id' => $db->insert_id]);
} else {
    echo json_encode(['success' => false, 'message' => 'Invalid request.']);
}

$db->close();
