<?php
require_once '../config.php';

$db = getDB();
$method = $_SERVER['REQUEST_METHOD'];
$action = $_GET['action'] ?? 'list';

if ($method === 'GET' && $action === 'list') {
    $result = $db->query("SELECT * FROM Customers ORDER BY customer_id");
    $rows = [];
    while ($row = $result->fetch_assoc()) $rows[] = $row;
    echo json_encode(['success' => true, 'data' => $rows]);

} elseif ($method === 'POST' && $action === 'add') {
    $input = json_decode(file_get_contents('php://input'), true);
    $name  = trim($input['name'] ?? '');
    $phone = trim($input['phone'] ?? '');
    $city  = trim($input['city'] ?? '');

    if (!$name || !$phone || !$city) {
        echo json_encode(['success' => false, 'message' => 'All fields are required.']);
        exit;
    }

    $stmt = $db->prepare("INSERT INTO Customers (name, phone, city) VALUES (?, ?, ?)");
    $stmt->bind_param('sss', $name, $phone, $city);
    if ($stmt->execute()) {
        echo json_encode(['success' => true, 'message' => 'Customer added successfully.', 'id' => $db->insert_id]);
    } else {
        echo json_encode(['success' => false, 'message' => 'Phone number already exists.']);
    }

} elseif ($method === 'POST' && $action === 'delete') {
    $input = json_decode(file_get_contents('php://input'), true);
    $id = intval($input['customer_id'] ?? 0);
    $stmt = $db->prepare("DELETE FROM Customers WHERE customer_id = ?");
    $stmt->bind_param('i', $id);
    $stmt->execute();
    echo json_encode(['success' => true, 'message' => 'Customer deleted.']);
} else {
    echo json_encode(['success' => false, 'message' => 'Invalid request.']);
}

$db->close();
