<?php
require_once '../config.php';

$db     = getDB();
$input  = json_decode(file_get_contents('php://input'), true);
$acc_id = intval($input['account_id'] ?? 0);
$amount = floatval($input['amount'] ?? 0);
$type   = strtoupper(trim($input['type'] ?? ''));

if (!$acc_id || $amount <= 0 || !in_array($type, ['DEPOSIT','WITHDRAW'])) {
    echo json_encode(['success' => false, 'message' => 'Invalid input. Check account ID, amount, and type.']);
    exit;
}

$stmt = $db->prepare("CALL DepositWithdraw(?, ?, ?)");
$stmt->bind_param('ids', $acc_id, $amount, $type);

if ($stmt->execute()) {
    $label = $type === 'DEPOSIT' ? 'Deposit' : 'Withdrawal';
    echo json_encode(['success' => true, 'message' => "$label of Rs. " . number_format($amount, 2) . " completed successfully."]);
} else {
    echo json_encode(['success' => false, 'message' => $db->error]);
}

$db->close();
